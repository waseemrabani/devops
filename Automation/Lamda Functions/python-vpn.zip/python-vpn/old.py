import subprocess
import socket
import boto3
import subprocess
import logging



dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('vpn_route')

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def run_command(command):
    command_list = command.split(' ')

    try:
        logger.info("Running shell command: \"{}\"".format(command))
        result = subprocess.run(command_list, stdout=subprocess.PIPE);
        logger.info("Command output:\n---\n{}\n---".format(result.stdout.decode('UTF-8')))
    except Exception as e:
        logger.error("Exception: {}".format(e))
        return False
        
    return True



def lambda_handler(event, context):

    domains = ["dev-b.yap.co", "dev-c.yap.co", "stg.yap.co", "qa-a.yap.co", "s1.yap.co", "gh-dev.yap.co", "s2.yap.co"]

    for domain in domains:

        ip_list = []
        addresses = socket.getaddrinfo(domain,0,0,0,0)
        for result in addresses:
            ip_list.append(result[-1][0])
        ip_list = list(set(ip_list))

        
        response = table.get_item(
            Key = {
                'domain_name': domain
            }
        )


        ip_address = response['Item']['address']

        ip_list.sort()
        ip_address.sort()

        
        if ( ip_list == ip_address ):
            print(f"Old and New IPs Matched for {domain}! Skipping VPN Route Changes!")
        else:
            print(f"Old and New don't Match for {domain}, Changing VPN Routes!")
            # print{$endpoint_id}
            
            for x in ip_list:
                print(x)
                run_command(f"/opt/aws ec2 create-client-vpn-route --client-vpn-endpoint-id cvpn-endpoint-0fbb86b7afe855ac4 --description route-for-{domain} --destination-cidr-block {x}/32 --target-vpc-subnet-id subnet-0d15c72ef7fbd4365")
                
            for x in ip_address:
                print(x)
                run_command(f"/opt/aws ec2 delete-client-vpn-route --client-vpn-endpoint-id cvpn-endpoint-0fbb86b7afe855ac4 --destination-cidr-block {x}/32 --target-vpc-subnet-id subnet-0d15c72ef7fbd4365")
            
            table.put_item(
                Item = {
                    'domain_name': domain,
                    'address': ip_list
                    }
                )
